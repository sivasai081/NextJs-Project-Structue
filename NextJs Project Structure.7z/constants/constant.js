export const BaseURL = process.env.API_BASEURL;


