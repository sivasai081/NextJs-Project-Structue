import css from 'styled-jsx/css'
export default css.global`


  `