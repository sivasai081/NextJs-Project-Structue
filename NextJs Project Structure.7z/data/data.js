export const allergiesData = {
  columns: [
    {
      label: 'DATES',
      field: 'startdate',
      width: "200",
      sort: 'asc', 
      
    },
    {
      label: 'ALLERGY',
      field: 'agdescription',
      width: "200",
      sort: 'asc',  
    },
    {
      label: 'STATUS',
      field: 'status',
      width: "200",
      sort: 'asc',
    },
  ],
  rows: []
};